/*
 * SER421-Summer25
 * Lab 6 , Activity 2
 * ndavispe , 7/4/25
 * 
 * src\main\java\com\example\surveyapi\model\QuestionType.java
 * Enum of supported question types for survey items
 */
package com.example.surveyapi.model;

public enum QuestionType {
    MCSA // Multiple Choise , Single Answer
}
