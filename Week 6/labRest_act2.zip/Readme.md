# ReadMe.md for Lab 6 Activity 2

### API Documentation
`./gradlew clean bootRun`
launch `http://localhost:8080/swagger-ui.html` in browser to display API documentation (built into Spring)