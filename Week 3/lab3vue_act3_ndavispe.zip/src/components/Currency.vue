<!-- Currency.vue -->
<!-- Activity 3 : multi-component Vue application -->
<!-- ndavispe, Lab3, 6/13/25 -->

<!-- setup -->

<script setup>
import { ref, computed, inject } from 'vue'

const amount = inject('amount')
const balance = inject('balance') // R4.
const convertfrom = inject('convertfrom')
const convertto = ref('USD')

const currencyfrom = [
  { name: "USD", desc: "US Dollar" },
  { name: "EUR", desc: "Euro" },
  { name: "INR", desc: "Indian Rupee" },
  { name: "BHD", desc: "Bahraini Dinar" }
]

const finalamount = computed(() => {
  const from = convertfrom.value
  const to = convertto.value
  const val = amount.value
  let final = 0

  switch (from) {
    case "INR":
      if (to === "USD") final = val * 0.016
      else if (to === "EUR") final = val * 0.013
      else if (to === "BHD") final = val * 0.0059
      else final = val
      break
    case "USD":
      if (to === "INR") final = val * 63.88
      else if (to === "EUR") final = val * 0.84
      else if (to === "BHD") final = val * 0.38
      else final = val
      break
    case "EUR":
      if (to === "INR") final = val * 76.22
      else if (to === "USD") final = val * 1.19
      else if (to === "BHD") final = val * 0.45
      else final = val
      break
    case "BHD":
      if (to === "INR") final = val * 169.44
      else if (to === "USD") final = val * 2.65
      else if (to === "EUR") final = val * 2.22
      else final = val
      break
  }
  return final.toFixed(2)
})

function swap() {
  const temp = convertfrom.value
  convertfrom.value = convertto.value
  convertto.value = temp
}
</script>

<template>
  <p>This example can be run directly in Vue SFC Playground</p>
  <div id="databinding">
    <h1>Currency Converter</h1>

    <span>Enter Amount:</span> <!-- R5. -->
    <input type="number" v-model.number="amount" /><br /><br />

    <span>Convert From:</span> <!-- R4. -->
    <select v-model="convertfrom" style="width:300px;font-size:15px;">
      <option v-for="a in currencyfrom" :key="a.name" :value="a.name">{{ a.desc }}</option>
    </select>

    <span>Convert To:</span> <!-- R4. -->
    <select v-model="convertto" style="width:300px;font-size:15px;">
      <option v-for="a in currencyfrom" :key="a.name" :value="a.name">{{ a.desc }}</option>
    </select><br /><br />

    <span>{{ amount }} {{ convertfrom }} equals {{ finalamount }} {{ convertto }}</span><br /><br />

    <button @click="swap()">swap</button>
  </div>
</template>

<style>
#databinding {
  padding: 20px 15px 15px 15px;
  margin: 0 0 25px 0;
  width: auto;
  background-color: #e7e7e7;
}
span, option, input {
  font-size: 15px;
}
</style>