/*
 * SER421-Summer25
 * Lab 6 , Activity 2
 * ndavispe , 7/4/25
 * 
 * src\main\java\com\example\surveyapi\model\SurveyInstanceState.java
 * JPA Entities
 */
package com.example.surveyapi.model;

public enum SurveyInstanceState {
    CREATED,
    IN_PROGRESS,
    COMPLETED
}
