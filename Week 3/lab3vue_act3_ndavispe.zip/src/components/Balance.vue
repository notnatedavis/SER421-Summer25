<!-- Balance.vue -->
<!-- Activity 3 : multi-component Vue application -->
<!-- ndavispe, Lab3, 6/13/25 -->

<!-- setup -->

<script setup>
import { inject } from 'vue'

const balance = inject('balance')
const amount = inject('amount')

function addBalance() {
  balance.value += amount.value
}

function subtractBalance() { // R3. 
  if (amount.value <= balance.value) {
    balance.value -= amount.value
  }
}
</script>

<template>
  <div class="greetings">
    <h3>Account Balance: {{ balance }} {{ inject('convertfrom') }}</h3>
    <h3>Amount: {{ amount }}</h3>

    <!-- R2. -->
    <input
      type="range"
      v-model="amount"
      min="5"
      max="100"
      step="5"
    />

    <button @click="addBalance">Add</button>
    <button @click="subtractBalance" :disabled="amount > balance">Subtract</button>
  </div>
</template>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}

input[type="range"] {
  width: 100%;
  margin: 10px 0;
}
</style>