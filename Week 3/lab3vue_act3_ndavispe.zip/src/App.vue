<!-- App.vue -->
<!-- Activity 3 : multi-component Vue application -->
<!-- ndavispe, Lab3, 6/13/25 -->

<!-- setup -->

<script setup>
import HelloWorld from './components/HelloWorld.vue'
import Balance from './components/Balance.vue'
import Currency from './components/Currency.vue'

// shared state
const balance = ref(100)
const amount = ref(10)
const convertfrom = ref('INR')

// provide state to descendents
provide('balance', balance)
provide('amount', amount)
provide('convertfrom', convertfrom)

const userName = 'ndavispe' // used in HelloWorld.vue
</script>

<template>
  <div id="app">
    <HelloWorld :name="userName" /> <!-- R1. -->
    <Balance />
    <Currency />
  </div>
</template>

<!-- maintain existing styles from github sample -->
 
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
